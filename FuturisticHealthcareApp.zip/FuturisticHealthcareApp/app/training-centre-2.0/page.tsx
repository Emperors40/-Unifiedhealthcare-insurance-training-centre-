'use client'

import { useEffect, useState } from 'react'
import { ProductionLine } from './types'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ProductionLineViewer } from './production-line-viewer'
import { ProductionLineList } from './production-line-list'
import { SimulationControls } from './simulation-controls'
import { getProductionLines, getIndustries } from './actions'

export default function TrainingCentre2() {
  const [lines, setLines] = useState<ProductionLine[]>([])
  const [industries, setIndustries] = useState<string[]>([])
  const [selectedLine, setSelectedLine] = useState<ProductionLine | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedIndustry, setSelectedIndustry] = useState<string>('all')
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [productionLines, industryList] = await Promise.all([
          getProductionLines(),
          getIndustries()
        ])
        setLines(productionLines)
        setIndustries(industryList)
      } catch (error) {
        console.error('Error fetching data:', error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  const filteredLines = lines.filter(line => {
    const matchesSearch = line.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      line.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesIndustry = selectedIndustry === 'all' || line.industry === selectedIndustry
    return matchesSearch && matchesIndustry
  })

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex items-center justify-center min-h-[400px]">
            <div className="text-muted-foreground">Loading production lines...</div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Training Centre 2.0</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <Input
                placeholder="Search production lines..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Select
                value={selectedIndustry}
                onValueChange={setSelectedIndustry}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filter by industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  {industries.map(industry => (
                    <SelectItem key={industry} value={industry}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-[1fr_2fr]">
          <ProductionLineList
            lines={filteredLines}
            selectedLine={selectedLine}
            onSelectLine={setSelectedLine}
          />

          {selectedLine ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>{selectedLine.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ProductionLineViewer line={selectedLine} />
                  <SimulationControls line={selectedLine} />
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center min-h-[400px] text-muted-foreground">
                Select a production line to view details
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

