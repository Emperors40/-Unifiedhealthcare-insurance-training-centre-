import { ScrollArea } from '@/components/ui/scroll-area'
import { ProductionLine } from './types'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

interface ProductionLineListProps {
  lines: ProductionLine[]
  selectedLine: ProductionLine | null
  onSelectLine: (line: ProductionLine) => void
}

export function ProductionLineList({
  lines,
  selectedLine,
  onSelectLine,
}: ProductionLineListProps) {
  return (
    <Card>
      <CardContent className="p-0">
        <ScrollArea className="h-[600px]">
          <div className="p-4 grid gap-2">
            {lines.map((line) => (
              <Button
                key={line.id}
                variant={selectedLine?.id === line.id ? 'default' : 'outline'}
                className="w-full justify-start"
                onClick={() => onSelectLine(line)}
              >
                <div className="flex items-center gap-4">
                  <img
                    src={line.thumbnailUrl}
                    alt={line.name}
                    className="w-12 h-12 rounded object-cover"
                  />
                  <div className="text-left">
                    <div className="font-medium">{line.name}</div>
                    <div className="text-sm text-muted-foreground">{line.industry}</div>
                  </div>
                </div>
              </Button>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

