'use client'

import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment } from '@react-three/drei'
import { ProductionLine } from './types'
import { ModelViewer } from './model-viewer'

interface ProductionLineViewerProps {
  line: ProductionLine
}

export function ProductionLineViewer({ line }: ProductionLineViewerProps) {
  return (
    <div className="w-full h-[400px] bg-muted rounded-lg overflow-hidden">
      <Canvas camera={{ position: [5, 5, 5], fov: 50 }}>
        <Suspense fallback={null}>
          <ModelViewer url={line.modelUrl} line={line} />
          <Environment preset="warehouse" />
          <OrbitControls />
        </Suspense>
      </Canvas>
    </div>
  )
}

