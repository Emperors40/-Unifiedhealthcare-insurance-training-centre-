'use server'

import { Parse } from '../lib/back4app'
import { 
  generateWithNvidia, 
  generate3DModel, 
  generateSimulation, 
  generateCADFiles,
  generateAssemblyInstructions as generateInstructions
} from '../lib/nvidia'
import { ProductionLine } from './types'

export async function getProductionLines(): Promise<ProductionLine[]> {
  const query = new Parse.Query('ProductionLine')
  const results = await query.find()
  
  return results.map(result => ({
    id: result.id,
    name: result.get('name'),
    description: result.get('description'),
    industry: result.get('industry'),
    components: result.get('components') || [],
    workflowStages: result.get('workflowStages') || [],
    modelUrl: result.get('modelUrl') || '/duck.glb',
    cadFileUrl: result.get('cadFileUrl') || '#',
    features: result.get('features') || [],
    thumbnailUrl: result.get('thumbnailUrl') || `/placeholder.svg?height=100&width=100`,
  }))
}

export async function getIndustries(): Promise<string[]> {
  const query = new Parse.Query('ProductionLine')
  const results = await query.find()
  return Array.from(new Set(results.map(result => result.get('industry'))))
}

export async function generateProductionLineDescription(name: string): Promise<string> {
  const prompt = `Generate a detailed description for a production line named "${name}". Include its purpose, key features, and potential applications.`
  return generateWithNvidia(prompt)
}

export async function generateAssemblyInstructions(line: ProductionLine): Promise<string[]> {
  try {
    const instructions = await generateInstructions(line.components)
    return Array.isArray(instructions) ? instructions : ['Unable to generate assembly instructions']
  } catch (error) {
    console.error('Error generating assembly instructions:', error)
    return ['Error generating assembly instructions']
  }
}

export async function generateModelData(line: ProductionLine) {
  try {
    const modelData = await generate3DModel(line.description)
    return modelData
  } catch (error) {
    console.error('Error generating model data:', error)
    return { modelUrl: '/duck.glb', error: 'Failed to generate model data' }
  }
}

export async function generateSimulationData(line: ProductionLine) {
  try {
    const modelData = await generateModelData(line)
    if (modelData.error) {
      throw new Error(modelData.error)
    }
    return generateSimulation(modelData)
  } catch (error) {
    console.error('Error generating simulation data:', error)
    return { defaultSpeed: 1, error: 'Failed to generate simulation data' }
  }
}

export async function generateCADFileData(line: ProductionLine) {
  try {
    const modelData = await generateModelData(line)
    if (modelData.error) {
      throw new Error(modelData.error)
    }
    return generateCADFiles(modelData)
  } catch (error) {
    console.error('Error generating CAD file data:', error)
    return { error: 'Failed to generate CAD file data' }
  }
}

