'use client'

import { useState, useEffect } from 'react'
import { ProductionLine } from './types'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Play, Pause, RotateCcw } from 'lucide-react'
import { generateAssemblyInstructions, generateModelData, generateSimulationData } from './actions'

interface SimulationControlsProps {
  line: ProductionLine
}

export function SimulationControls({ line }: SimulationControlsProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(1)
  const [currentStage, setCurrentStage] = useState(0)
  const [instructions, setInstructions] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadInstructions = async () => {
      try {
        // Use Promise.all to fetch all data in parallel from server actions
        const [instructions, modelData, simulationData] = await Promise.all([
          generateAssemblyInstructions(line),
          generateModelData(line),
          generateSimulationData(line)
        ])
        setInstructions(instructions)
        // Update simulation state with the new data
        if (simulationData) {
          setSpeed(simulationData.defaultSpeed || 1)
        }
      } catch (error) {
        console.error('Error loading data:', error)
        setInstructions(['Error loading instructions'])
      } finally {
        setIsLoading(false)
      }
    }

    loadInstructions()
  }, [line])

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const reset = () => {
    setIsPlaying(false)
    setCurrentStage(0)
  }

  return (
    <div className="space-y-4 pt-4">
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={togglePlay}
          disabled={isLoading}
        >
          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={reset}
          disabled={isLoading}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
        <div className="flex-1 px-4">
          <Slider
            value={[speed]}
            onValueChange={(value) => setSpeed(value[0])}
            min={0.5}
            max={2}
            step={0.1}
            disabled={isLoading}
          />
        </div>
        <div className="w-12 text-right text-sm">
          {speed.toFixed(1)}x
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-sm font-medium">Assembly Instructions:</div>
        <div className="space-y-1">
          {isLoading ? (
            <div className="p-2 rounded bg-muted text-sm">Loading instructions...</div>
          ) : (
            instructions.map((instruction, index) => (
              <div
                key={index}
                className={`p-2 rounded text-sm ${
                  index === currentStage
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                {instruction}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}

