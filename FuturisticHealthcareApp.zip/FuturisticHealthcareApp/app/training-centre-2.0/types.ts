export interface ProductionLine {
  id: string
  name: string
  description: string
  industry: string
  components: string[]
  workflowStages: string[]
  modelUrl: string
  cadFileUrl: string
  features: string[]
  thumbnailUrl: string
}

export interface SimulationState {
  isRunning: boolean
  speed: number
  currentStage: number
}

