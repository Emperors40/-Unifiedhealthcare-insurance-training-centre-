'use client'

import { useEffect, useState } from 'react'
import { useLoader } from '@react-three/fiber'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'
import { generateModelData } from './actions'

interface ModelViewerProps {
  url: string
  line?: any // Add line prop for generating custom models
}

export function ModelViewer({ url, line }: ModelViewerProps) {
  const [modelUrl, setModelUrl] = useState(url)
  const gltf = useLoader(GLTFLoader, modelUrl)

  useEffect(() => {
    if (line) {
      const loadCustomModel = async () => {
        try {
          // Call server action to generate model data
          const modelData = await generateModelData(line)
          if (modelData?.modelUrl) {
            setModelUrl(modelData.modelUrl)
          }
        } catch (error) {
          console.error('Error loading custom model:', error)
        }
      }
      loadCustomModel()
    }
  }, [line])

  return <primitive object={gltf.scene} scale={2} />
}

