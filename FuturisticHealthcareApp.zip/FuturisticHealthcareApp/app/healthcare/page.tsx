'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { CameraFeed } from '@/components/camera-feed'
import { cameraService } from '@/lib/camera-service'

export default function Healthcare() {
  const [scanResult, setScanResult] = useState<string | null>(null)
  const [showCamera, setShowCamera] = useState(false)
  const [isBackgroundScanning, setIsBackgroundScanning] = useState(false)

  useEffect(() => {
    // Initialize background scanning
    startBackgroundScanning()
    return () => {
      cameraService.stopBackgroundScanning()
    }
  }, [])

  const startBackgroundScanning = async () => {
    const success = await cameraService.startBackgroundScanning((imageData) => {
      // Process the background scan
      processHealthScan(imageData)
    })
    setIsBackgroundScanning(success)
  }

  const processHealthScan = async (imageData: ImageData) => {
    setScanResult("Processing health scan... (analyzing camera data)")
    // Simulating backend call
    await new Promise(resolve => setTimeout(resolve, 2000))
    setScanResult("Scan complete. Health metrics updated.")
  }

  const startManualScan = () => {
    setShowCamera(true)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Healthcare Monitoring</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Background Scanning</h3>
                <p className="text-sm text-muted-foreground">
                  Status: {isBackgroundScanning ? 'Active' : 'Inactive'}
                </p>
              </div>
              <Button onClick={startManualScan}>Perform Manual Scan</Button>
            </div>
            
            {showCamera && (
              <CameraFeed
                onFrame={processHealthScan}
                autoStart={true}
              />
            )}

            {scanResult && (
              <div className="p-4 bg-muted rounded-lg">
                <p>{scanResult}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

