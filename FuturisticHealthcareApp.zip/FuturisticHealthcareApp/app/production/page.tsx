'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function Production() {
  const [description, setDescription] = useState('')
  const [generatedFiles, setGeneratedFiles] = useState<string | null>(null)

  const generateDesign = async () => {
    if (!description) {
      alert('Please describe your production line.')
      return
    }
    setGeneratedFiles("Generating CAD and 3D Models...")
    // Simulating backend call
    await new Promise(resolve => setTimeout(resolve, 2000))
    setGeneratedFiles(`Generated CAD and 3D Models for: ${description}`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Production Line</CardTitle>
      </CardHeader>
      <CardContent>
        <Textarea
          placeholder="Describe your production line..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="mb-4"
        />
        <Button onClick={generateDesign}>Generate CAD and 3D Models</Button>
        {generatedFiles && (
          <p className="mt-4">{generatedFiles}</p>
        )}
      </CardContent>
    </Card>
  )
}

