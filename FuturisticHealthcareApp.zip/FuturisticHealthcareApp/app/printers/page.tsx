'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function Printers() {
  const [simulationResult, setSimulationResult] = useState<string | null>(null)

  const simulatePrinter = async () => {
    setSimulationResult("Simulating multi-material 3D printer... (sending to backend)")
    // Simulating backend call
    await new Promise(resolve => setTimeout(resolve, 2000))
    setSimulationResult("Simulation complete. Results: Optimal print settings determined for multi-material printing.")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>3D Printers</CardTitle>
      </CardHeader>
      <CardContent>
        <Button onClick={simulatePrinter}>Simulate Multi-Material 3D Printer</Button>
        {simulationResult && (
          <p className="mt-4">{simulationResult}</p>
        )}
      </CardContent>
    </Card>
  )
}

