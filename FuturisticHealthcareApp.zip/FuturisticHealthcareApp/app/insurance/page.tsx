'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function Insurance() {
  const [hospitals, setHospitals] = useState<string[]>([])
  const [medicalHistory, setMedicalHistory] = useState<string[]>([])

  useEffect(() => {
    // Simulating API call to fetch data
    const fetchData = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000))
      setHospitals(["St. Mary's Hospital, Lagos", "General Hospital, Abuja"])
      setMedicalHistory([
        "2023-05-15: Annual check-up",
        "2022-11-03: Flu vaccination",
        "2022-03-20: Sprained ankle treatment"
      ])
    }
    fetchData()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Insurance</CardTitle>
      </CardHeader>
      <CardContent>
        <h3 className="text-lg font-semibold mb-2">Subscriber Details</h3>
        <p className="mb-4">Hospitals: {hospitals.join(', ')}</p>
        <h4 className="text-md font-semibold mb-2">Medical History:</h4>
        <ul className="list-disc pl-5">
          {medicalHistory.map((record, index) => (
            <li key={index}>{record}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

