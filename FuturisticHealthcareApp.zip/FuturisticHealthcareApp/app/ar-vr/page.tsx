'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'

export default function ARVRAssembly() {
  const [step, setStep] = useState(0)
  const assemblySteps = [
    "Place the 3D printed base on a flat surface.",
    "Attach the main support structure to the base.",
    "Connect the electronic components to the main board.",
    "Secure the print head to the support structure.",
    "Install the filament feeding mechanism.",
    "Calibrate the printer bed and test the movements."
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">AR/VR Assembly Guide</h1>
      <div className="max-w-md">
        <div className="mb-4 p-4 bg-muted rounded">
          <h2 className="text-xl font-semibold mb-2">Step {step + 1}</h2>
          <p>{assemblySteps[step]}</p>
        </div>
        <div className="flex justify-between">
          <Button onClick={() => setStep(Math.max(0, step - 1))} disabled={step === 0}>Previous Step</Button>
          <Button onClick={() => setStep(Math.min(assemblySteps.length - 1, step + 1))} disabled={step === assemblySteps.length - 1}>Next Step</Button>
        </div>
      </div>
    </div>
  )
}

