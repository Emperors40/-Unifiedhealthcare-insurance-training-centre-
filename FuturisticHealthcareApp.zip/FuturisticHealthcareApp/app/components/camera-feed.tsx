'use client'

import { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Camera, CameraOff } from 'lucide-react'

interface CameraFeedProps {
  onFrame?: (imageData: ImageData) => void
  autoStart?: boolean
}

export function CameraFeed({ onFrame, autoStart = false }: CameraFeedProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isActive, setIsActive] = useState(false)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)

  useEffect(() => {
    if (autoStart) {
      startCamera()
    }
    return () => stopCamera()
  }, [autoStart])

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment',
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      })
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsActive(true)
        setHasPermission(true)
        
        if (onFrame) {
          startFrameCapture(stream)
        }
      }
    } catch (error) {
      console.error('Error accessing camera:', error)
      setHasPermission(false)
    }
  }

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach(track => track.stop())
      videoRef.current.srcObject = null
      setIsActive(false)
    }
  }

  const startFrameCapture = (stream: MediaStream) => {
    if (!canvasRef.current || !onFrame) return

    const video = videoRef.current!
    const canvas = canvasRef.current
    const context = canvas.getContext('2d')
    
    if (!context) return

    video.addEventListener('play', () => {
      const captureFrame = () => {
        if (video.paused || video.ended) return
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        context.drawImage(video, 0, 0)
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height)
        onFrame(imageData)
        requestAnimationFrame(captureFrame)
      }
      captureFrame()
    })
  }

  const toggleCamera = () => {
    if (isActive) {
      stopCamera()
    } else {
      startCamera()
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          Camera Feed
          <Button
            variant="outline"
            size="icon"
            onClick={toggleCamera}
            disabled={hasPermission === false}
          >
            {isActive ? (
              <CameraOff className="h-4 w-4" />
            ) : (
              <Camera className="h-4 w-4" />
            )}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {hasPermission === false ? (
          <div className="text-center text-muted-foreground">
            Camera access denied. Please check your browser settings.
          </div>
        ) : (
          <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
            <canvas
              ref={canvasRef}
              className="hidden"
            />
          </div>
        )}
      </CardContent>
    </Card>
  )
}

