'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'

export function Navigation() {
  const pathname = usePathname()

  const links = [
    { href: '/', label: 'Home' },
    { href: '/healthcare', label: 'Healthcare' },
    { href: '/insurance', label: 'Insurance' },
    { href: '/training-centre', label: 'Training Centre' },
    { href: '/training-centre-2.0', label: 'Training Centre 2.0' },
    { href: '/production', label: 'Production Line' },
    { href: '/printers', label: '3D Printers' },
  ]

  return (
    <nav className="bg-secondary p-4">
      <div className="container mx-auto flex flex-wrap justify-center gap-2">
        {links.map((link) => (
          <Link key={link.href} href={link.href} passHref>
            <Button
              variant={pathname === link.href ? 'default' : 'ghost'}
              className="text-secondary-foreground"
            >
              {link.label}
            </Button>
          </Link>
        ))}
      </div>
    </nav>
  )
}

