'use client'

export class CameraService {
  private stream: MediaStream | null = null;
  private intervalId: NodeJS.Timeout | null = null;

  async requestPermissions(): Promise<boolean> {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      return true;
    } catch (error) {
      console.error('Camera permission denied:', error);
      return false;
    }
  }

  async startCamera(): Promise<MediaStream | null> {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment',
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      return this.stream;
    } catch (error) {
      console.error('Error starting camera:', error);
      return null;
    }
  }

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  }

  async startBackgroundScanning(callback: (imageData: ImageData) => void) {
    const hasPermission = await this.requestPermissions();
    if (!hasPermission) return false;

    const stream = await this.startCamera();
    if (!stream) return false;

    const video = document.createElement('video');
    video.srcObject = stream;
    await video.play();

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    if (!context) return false;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    this.intervalId = setInterval(() => {
      context.drawImage(video, 0, 0);
      const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
      callback(imageData);
    }, 1000); // Scan every second

    return true;
  }

  stopBackgroundScanning() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.stopCamera();
  }
}

export const cameraService = new CameraService();

