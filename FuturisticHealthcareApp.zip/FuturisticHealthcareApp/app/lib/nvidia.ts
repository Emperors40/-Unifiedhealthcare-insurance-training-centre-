interface NvidiaResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

// Specific model selections for different tasks
const MODELS = {
  CAD: "qwen/qwen2.5-coder-7b-instruct", // Best for CAD file generation
  SIMULATION: "mixtral/mixtral-8x7b-instruct", // Better for physics and simulation
  MODEL_3D: "qwen/qwen2.5-coder-7b-instruct", // Optimized for 3D model generation
  INSTRUCTIONS: "llama/llama-2-70b-instruct", // Best for natural language instructions
}

async function callNvidiaAPI(prompt: string, model: string) {
  try {
    const response = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer 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`
      },
      body: JSON.stringify({
        model: model,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.2,
        top_p: 0.7,
        max_tokens: 1024,
      })
    })

    if (!response.ok) {
      throw new Error(`NVIDIA API error: ${response.statusText}`)
    }

    const data: NvidiaResponse = await response.json()
    return data.choices[0]?.message?.content || ''
  } catch (error) {
    console.error('Error calling NVIDIA API:', error)
    throw new Error('Failed to generate response')
  }
}

export async function generate3DModel(description: string) {
  try {
    const prompt = `
      Generate a detailed 3D model specification in JSON format for: ${description}
      Include:
      - Geometry specifications
      - Material properties
      - Textures
      - Scale and dimensions
      - Assembly points
      Format as valid JSON with these properties.
    `
    const response = await callNvidiaAPI(prompt, MODELS.MODEL_3D)
    const modelData = JSON.parse(response)
    return {
      ...modelData,
      modelUrl: modelData.modelUrl || '/duck.glb' // Fallback to default model
    }
  } catch (error) {
    console.error('Error generating 3D model:', error)
    return {
      modelUrl: '/duck.glb',
      error: 'Failed to generate custom model'
    }
  }
}

export async function generateSimulation(modelData: any) {
  try {
    const prompt = `
      Create detailed simulation parameters in JSON format for 3D model:
      ${JSON.stringify(modelData)}
      Include:
      - Physics properties
      - Movement constraints
      - Animation keyframes
      - Interaction points
      - Performance optimization settings
      Format as valid JSON with these properties.
    `
    const response = await callNvidiaAPI(prompt, MODELS.SIMULATION)
    return JSON.parse(response)
  } catch (error) {
    console.error('Error generating simulation:', error)
    return {
      defaultSpeed: 1,
      error: 'Failed to generate simulation parameters'
    }
  }
}

export async function generateCADFiles(modelData: any) {
  try {
    const prompt = `
      Generate CAD file specifications in JSON format for 3D model:
      ${JSON.stringify(modelData)}
      Include:
      - Technical drawings
      - Measurements
      - Material specifications
      - Assembly instructions
      - Manufacturing guidelines
      Format as valid JSON with these properties.
    `
    const response = await callNvidiaAPI(prompt, MODELS.CAD)
    return JSON.parse(response)
  } catch (error) {
    console.error('Error generating CAD files:', error)
    return {
      error: 'Failed to generate CAD specifications'
    }
  }
}

export async function generateAssemblyInstructions(components: string[]) {
  try {
    const prompt = `
      Generate detailed step-by-step assembly instructions for components:
      ${components.join(', ')}
      Format as a JSON array of strings with clear, numbered steps.
    `
    const response = await callNvidiaAPI(prompt, MODELS.INSTRUCTIONS)
    return JSON.parse(response)
  } catch (error) {
    console.error('Error generating assembly instructions:', error)
    return ['Unable to generate assembly instructions']
  }
}

export async function generateWithNvidia(prompt: string, model = MODELS.INSTRUCTIONS) {
  return callNvidiaAPI(prompt, model)
}

