import Parse from 'parse/dist/parse.min.js'

// Initialize Parse
Parse.initialize(
  process.env.BACK4APP_APPLICATION_ID!,
  process.env.BACK4APP_JAVASCRIPT_KEY!
)

// Set server URL
Parse.serverURL = 'https://parseapi.back4app.com'

export { Parse }

