import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Navigation } from './components/navigation'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Unified Healthcare/Insurance and Training Centre',
  description: 'Advanced healthcare, insurance, and manufacturing solutions',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-primary text-primary-foreground p-4">
          <h1 className="text-2xl font-bold text-center">Unified Healthcare/Insurance and Training Centre</h1>
        </header>
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          {children}
        </main>
        <footer className="bg-muted p-4 text-center">
          <p>&copy; 2024 Unified Healthcare/Insurance and Training Centre</p>
        </footer>
      </body>
    </html>
  )
}

