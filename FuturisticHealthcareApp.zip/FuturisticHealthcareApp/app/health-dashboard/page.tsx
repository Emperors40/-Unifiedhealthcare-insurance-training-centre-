'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CameraFeed } from '@/components/camera-feed'
import { cameraService } from '@/lib/camera-service'
import { Camera } from 'lucide-react'

export default function HealthDashboard() {
  const [isBackgroundScanning, setIsBackgroundScanning] = useState(false)
  const [showCameraFeed, setShowCameraFeed] = useState(false)
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null)
  const [healthMetrics, setHealthMetrics] = useState({
    heartRate: '72 bpm',
    bloodPressure: '120/80 mmHg',
    stepsToday: '8,547',
    sleep: '7h 30m',
    caloriesBurned: '2,350 kcal',
    stressLevel: 'Low'
  })

  useEffect(() => {
    // Start background scanning on component mount
    startBackgroundScanning()
    return () => {
      cameraService.stopBackgroundScanning()
    }
  }, [])

  const startBackgroundScanning = async () => {
    const success = await cameraService.startBackgroundScanning((imageData) => {
      // Process the scan data
      processScanData(imageData)
    })
    setIsBackgroundScanning(success)
  }

  const processScanData = (imageData: ImageData) => {
    // Here you would typically send the image data to your backend for processing
    // For this example, we'll just update the last scan time
    setLastScanTime(new Date())
    
    // Simulate updating health metrics
    setHealthMetrics(prev => ({
      ...prev,
      heartRate: `${Math.floor(65 + Math.random() * 20)} bpm`
    }))
  }

  const handleManualScan = (imageData: ImageData) => {
    processScanData(imageData)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">Health Dashboard</h1>
        <Button
          onClick={() => setShowCameraFeed(!showCameraFeed)}
          className="flex items-center gap-2"
        >
          <Camera className="h-4 w-4" />
          {showCameraFeed ? 'Hide Camera' : 'Show Camera'}
        </Button>
      </div>

      {showCameraFeed && (
        <div className="mb-4">
          <CameraFeed onFrame={handleManualScan} />
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Heart Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{healthMetrics.heartRate}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Blood Pressure</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{healthMetrics.bloodPressure}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Steps Today</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{healthMetrics.stepsToday}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Sleep</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{healthMetrics.sleep}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Calories Burned</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{healthMetrics.caloriesBurned}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Stress Level</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{healthMetrics.stressLevel}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Scanning Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p>
              Background Scanning: 
              <span className={`ml-2 font-medium ${isBackgroundScanning ? 'text-green-600' : 'text-red-600'}`}>
                {isBackgroundScanning ? 'Active' : 'Inactive'}
              </span>
            </p>
            {lastScanTime && (
              <p>
                Last Scan: 
                <span className="ml-2 font-medium">
                  {lastScanTime.toLocaleTimeString()}
                </span>
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

