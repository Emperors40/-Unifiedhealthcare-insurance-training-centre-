import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function Home() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Link href="/healthcare">
        <Button className="w-full h-32 text-lg">Healthcare</Button>
      </Link>
      <Link href="/insurance">
        <Button className="w-full h-32 text-lg">Insurance</Button>
      </Link>
      <Link href="/training-centre">
        <Button className="w-full h-32 text-lg">Training Centre</Button>
      </Link>
      <Link href="/production">
        <Button className="w-full h-32 text-lg">Production Line</Button>
      </Link>
      <Link href="/printers">
        <Button className="w-full h-32 text-lg">3D Printers</Button>
      </Link>
    </div>
  )
}

