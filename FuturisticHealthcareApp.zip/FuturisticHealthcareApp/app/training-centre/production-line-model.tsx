'use client'

import { useEffect, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Box, Cylinder, Html } from '@react-three/drei'
import { Group } from 'three'

interface ProductionLineModelProps {
  lineId: string
}

export function ProductionLineModel({ lineId }: ProductionLineModelProps) {
  const groupRef = useRef<Group>(null)

  useFrame((state) => {
    if (groupRef.current) {
      // Subtle rotation animation
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.1) * 0.1
    }
  })

  return (
    <group ref={groupRef}>
      {/* Base platform */}
      <Box args={[4, 0.2, 2]} position={[0, -0.1, 0]}>
        <meshStandardMaterial color="#444" />
      </Box>

      {/* Conveyor belt */}
      <Box args={[3, 0.1, 0.8]} position={[0, 0.2, 0]}>
        <meshStandardMaterial color="#666" />
      </Box>

      {/* Support columns */}
      {[-1.8, 1.8].map((x) => (
        <Cylinder
          key={x}
          args={[0.1, 0.1, 1.5, 16]}
          position={[x, 0.75, 0]}
        >
          <meshStandardMaterial color="#555" />
        </Cylinder>
      ))}

      {/* Top beam */}
      <Box args={[4, 0.2, 0.2]} position={[0, 1.5, 0]}>
        <meshStandardMaterial color="#444" />
      </Box>

      {/* Production line label */}
      <Html
        position={[0, 2, 0]}
        center
        className="pointer-events-none"
      >
        <div className="bg-background/80 px-2 py-1 rounded text-sm whitespace-nowrap">
          {lineId}
        </div>
      </Html>

      {/* Ambient light */}
      <ambientLight intensity={0.5} />
      
      {/* Directional light */}
      <directionalLight
        position={[5, 5, 5]}
        intensity={1}
        castShadow
      />
    </group>
  )
}

