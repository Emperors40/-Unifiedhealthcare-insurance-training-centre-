'use client'

import { useState, Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment } from '@react-three/drei'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ProductionLineModel } from './production-line-model'
import { Button } from '@/components/ui/button'

export default function TrainingCentre() {
  const [selectedLine, setSelectedLine] = useState<string>('')
  const [isStarted, setIsStarted] = useState(false)

  // Generate array of 150 production lines
  const productionLines = Array.from({ length: 150 }, (_, i) => ({
    value: `line-${i + 1}`,
    label: `Production Line ${i + 1}`
  }))

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Training Centre</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-4">
              <Select
                value={selectedLine}
                onValueChange={setSelectedLine}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a production line" />
                </SelectTrigger>
                <SelectContent>
                  {productionLines.map((line) => (
                    <SelectItem key={line.value} value={line.value}>
                      {line.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                onClick={() => setIsStarted(true)} 
                disabled={!selectedLine}
                className="w-full"
              >
                Start Training
              </Button>
            </div>
            {selectedLine && (
              <div className="text-sm space-y-2">
                <h3 className="font-medium">Selected Production Line Details:</h3>
                <p>Line ID: {selectedLine}</p>
                <p>Status: Active</p>
                <p>Training Module: Basic Operations</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedLine && (
        <Card>
          <CardHeader>
            <CardTitle>3D Production Line View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full h-[500px] bg-muted rounded-lg overflow-hidden">
              <Canvas camera={{ position: [5, 5, 5], fov: 50 }}>
                <Suspense fallback={null}>
                  <ProductionLineModel lineId={selectedLine} />
                  <Environment preset="warehouse" />
                  <OrbitControls />
                </Suspense>
              </Canvas>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

